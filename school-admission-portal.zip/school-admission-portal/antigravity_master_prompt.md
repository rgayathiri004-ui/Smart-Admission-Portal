# MASTER PROMPT FOR ANTIGRAVITY: "School Admission Portal – Thoothukudi" (real-time working prototype)

Paste everything below this line into Antigravity. Put `schools_thoothukudi.json` in the project folder first.

---

## 1. Goal

Build a complete, working, real-time prototype web application called **"School Admission Portal"** (working title; you may refine the name) for parents in **Thoothukudi district, Tamil Nadu, India**. A parent can apply for admission to a real school in Thoothukudi from one place, through a friendly chatbot, then track the application while the school's staff review it. The prototype must run end to end locally with one command and must be designed so real services (SMS, database, file storage) plug in through environment variables.

All school data must be REAL. Use only the file `schools_thoothukudi.json` as the data source. Never invent schools, addresses, phone numbers, websites, fees, or principal names. If a field is `null`, show nothing or "Not available". Each record has a `verification` field ("official" or "directory"); show a small "Verified" badge for `official` and "Listed – confirm with school" for `directory`. Keep the `sources` array and show a "Source" link in the school detail drawer.

## 2. Tech stack (use unless you have a strong reason not to)

- Next.js (App Router) + TypeScript + Tailwind CSS, with shadcn/ui components.
- Node API routes, Prisma ORM, SQLite for the prototype (schema must be portable to PostgreSQL).
- Real-time updates: Server-Sent Events or WebSocket so the staff dashboard and the parent's tracking page update live when status changes.
- PDF generation: server-side (pdf-lib or Puppeteer) for the application copy.
- File uploads: local disk storage behind a storage adapter (swap to S3/GCS later). Accept PDF/JPG/PNG up to 5 MB each.
- SMS: provider adapter pattern in `lib/sms/` with these implementations: `MSG91Provider`, `TwilioProvider`, `Fast2SMSProvider`, and `ConsoleProvider` (logs the message, used when no keys are set). Selected by `SMS_PROVIDER` env var. Put placeholders in `.env.example`. Add a clear banner in the UI whenever the app is running with ConsoleProvider: "Demo mode: SMS is not actually sent."
- Mobile OTP login with a 6-digit OTP (hashed, 5-minute expiry, max 3 attempts, rate limited).
- Mobile-first responsive layout; must look good on a phone because most parents will use one.
- Bilingual UI: English and Tamil, with a language toggle on every page. Chatbot questions must be available in both languages.

## 3. Visual design

- **Light, calm, trustworthy colours only.** Suggested palette: soft white background (#FAFCFF), pale sky blue (#E8F3FF), mint (#E6F7F1), soft peach accent (#FFF1E6), primary blue (#3B82F6 or a gentler #5B9DF5), text slate (#1F2A44). No dark mode, no heavy gradients, no black backgrounds.
- Rounded cards (16–20 px radius), generous spacing, large readable type, friendly icons (lucide-react), subtle shadows, smooth micro-animations.
- Accessible: WCAG AA contrast, visible focus rings, large tap targets (min 44 px), labels on every input.
- Every screen (except the landing page) has a clear **Back** button at the top-left that returns to the previous step without losing entered data.

## 4. Pages and flows (follow exactly)

### 4.1 Landing page
- Hero with the title "School Admission Portal", a one-line promise ("Apply to your child's school in Thoothukudi, simply."), a soft illustration, and a primary button "Get Started".
- Below: 3-step "How it works" strip, a list of school boards covered, and a short trust/privacy note.
- Light colours, clean and professional.

### 4.2 Welcome page (after clicking Get Started)
- Parent enters **Parent / Guardian name** and **10-digit Indian mobile number** (validate: starts with 6–9, 10 digits, +91 prefix shown).
- Press "Send OTP" → enter OTP → verified session created. (In demo mode the OTP is shown in a dev-only toast and in the server console.)
- Returning parents with the same mobile see their existing applications.
- On success go to the "Choose how to start" page.

### 4.3 Choose how to start
Two large option cards:
1. **Start from School** – choose a school first, then apply to that school.
2. **Start from Application** – prepare the application first, then choose a school.

Back button returns to the Welcome page.

### 4.4 METHOD 1 – Start from School

**Step 1 – School list (real Thoothukudi data)**
- Load schools from `schools_thoothukudi.json` (through an API route backed by the DB, seeded from that file).
- **Search box**: live search by school name, area, or pincode.
- **"All boards" filter**: dropdown/chips generated dynamically from the boards actually present in the data (expect State Board, Matriculation, CBSE, ICSE). Selecting a board filters the list; show counts per board.
- Each school card shows: name, board badge, area, classes (if known), verification badge, and two buttons:
  - **View Website** → opens the school's real website in a new tab (`target="_blank" rel="noopener noreferrer"`). If the website is `null`, disable the button and show "Website not available".
  - **Select this school** → goes to Step 2.
- Add a **Compare** checkbox on each card (see 4.7) in this flow too.

**Step 2 – School chatbot (collects the application)**
- Opens a chat interface branded with the selected school's name. The bot asks **exactly 10 main questions**, one at a time (see section 5), with typed answers, quick-reply chips, date pickers and dropdowns where suitable. Show progress "Question 3 of 10".
- After each answer the bot echoes it back and confirms.
- **Edit / Delete controls:** every answered message has an Edit (pencil) and Delete (bin) icon. Editing re-opens that question with the old value pre-filled; deleting clears the answer and the bot re-asks it. A "Review all answers" side panel lists all answers with edit/delete next to each.
- When all 10 answers are entered, the bot says it is done and moves to Step 3.

**Step 3 – Generated application form (review)**
- Auto-generate a clean, printable-looking **application form** from the chat answers, with the school name/logo placeholder, a photo box, and all fields grouped in sections.
- Every field has an inline "Edit" link that jumps back to the matching chatbot question.
- Parent must tick "I have checked all details and they are correct" and press **Verify & Continue**. The button stays disabled until the form is complete and the checkbox is ticked.

**Step 4 – Document upload**
- Checklist of required documents (section 6) with upload buttons, drag & drop, thumbnails, replace and remove.
- Required vs optional flags; cannot continue until all required documents are uploaded.

**Step 5 – Final review and Confirm Application**
- Show the full form plus the list of uploaded documents.
- Button **Confirm Application**.
- On click: create the application, generate a unique **Application ID** (format `TKD-2026-XXXXXX`, where X is from a non-confusable alphabet), show a success screen with the ID, a QR code of the ID, a "Download PDF copy" button, and a "Track application" button.
- The ID is attached to the selected school and routed to that school's approval workflow (section 7).

### 4.5 METHOD 2 – Start from Application
1. The same **chatbot** (10 questions, with edit/delete) but without a school selected yet.
2. The same **generated form review** with verify checkbox.
3. The same **document upload** step.
4. **Full application preview** – the entire form and all documents are displayed for a final check. Only after this check, show a button **"Proceed to choose school"** (or "Submit application" – label it clearly as "Next: choose school").
5. **School list** exactly like 4.4 Step 1 (search, All boards filter, View Website, Select this school, Compare checkbox) plus a **Compare** button.
6. When the parent presses **Select this school** and confirms, create the application, generate the **Application ID**, and route it to the selected school's approval workflow. Then show the same success screen as Method 1.

### 4.6 Back navigation
Every step in both methods has a Back button; going back never loses data (persist drafts in the database keyed by the parent's session and also in local storage as a fallback). Browser back button must behave sensibly too.

### 4.7 School comparison (important, available in Method 2 and also from Method 1's list)
- Parent can tick up to 3 schools and press **Compare**.
- A comparison page shows schools side by side: board, area, classes, gender, medium, management, established year, website link, verification level, source link, distance from the parent's pincode if available (optional), and any known phone numbers. Missing fields show "Not available" (never invented).
- Each column has **Select this school** and **View Website** buttons.
- Highlight rows where schools differ. Do NOT show fake ratings, fake fees, or fake rankings. If you want a recommendation helper, base it only on fields that exist in the data and say which fields were used.

## 5. The 10-question chatbot (define these in a JSON config so they are editable per school)

Ask in this order. Each question has English + Tamil text, validation, and a type.

1. Student's full name (as in birth certificate)
2. Date of birth (date picker; compute age as of 31 March of the academic year and warn if below/above the school's usual age for the class)
3. Gender (Male / Female / Other)
4. Class applying for (Pre-KG, LKG, UKG, 1–12; dropdown filtered by the school's `classes` if known)
5. Father's name and occupation
6. Mother's name and occupation
7. Residential address with pincode (validate Thoothukudi-area pincodes 628xxx but allow others with a warning)
8. Previous school name and last class completed (skip with "New to school" for Pre-KG/LKG)
9. Mother tongue, religion and community category (OC / BC / MBC / SC / ST) – optional-with-consent, clearly explained as needed for state records
10. Any special needs, medical conditions, or allergies we should tell the school (optional, with "None" chip)

Parent name and mobile come from the Welcome page and are auto-filled. Let schools add extra questions in config, but keep the main flow at 10.

## 6. Required documents (config-driven)

- Birth certificate (required)
- Passport-size photo of the student (required)
- Aadhaar of student or parent (required, with a note that it is stored securely and masked on screen)
- Address proof (required)
- Transfer Certificate (required from Class 2 onwards)
- Previous year report card / mark sheet (required from Class 2 onwards)
- Community certificate (required if a community category other than OC is chosen)
- Medical or disability certificate (optional)

## 7. Approval workflow (after Application ID is generated)

Each application goes to the **selected school only**, through four stages in this fixed order:

1. **Class Teacher**
2. **Principal**
3. **Admission Committee**
4. **Final Approving Authority**

Rules:
- Each stage can **view the full application and documents** and then choose **Approve**, **Reject** (reason mandatory), or **Request more information** (message goes to the parent).
- Only after a stage approves does the application move to the next stage. A rejection ends the application and notifies the parent with the reason.
- Role-based access control: a staff account can see only its own school's applications and only the stage matching its role.
- Provide a **Staff dashboard** (separate login at `/staff`) with filters by stage/status, search by Application ID, a detail view with document viewer, and an audit trail (who, when, decision, note).
- Seed **demo staff accounts** for each seeded school with clearly fake credentials (for example `demo-teacher-tk-001`). Real staff accounts must come from the school's own onboarding; do not pretend any real person is a user.
- The parent's **Track Application** page (login by mobile OTP + Application ID) shows a live timeline of the four stages and updates in real time.

## 8. Notifications and PDF (real mobile number)

When the **Final Approving Authority** approves, send an SMS to the parent's verified mobile number with a warm, clear message. Use this text (English) and also send a Tamil version:

> "Congratulations! Your child {studentName} has been selected for admission to {schoolName}, Thoothukudi (Application ID {applicationId}). Please check your application copy and visit the school office with the original documents. – School Admission Portal"

Also:
- Generate the **application copy as a PDF** (form, student details, document list, Application ID, QR code, timestamp) and make it available to the parent through a secure download link that is sent in the SMS or shown after login. (Plain SMS cannot carry a PDF; send a short secure link and also offer WhatsApp delivery via a provider adapter as an optional extension.)
- Send SMS also at: OTP, application confirmed (with ID), each rejection / request-for-info, and final selection.
- Log every notification (to, template, provider response, status) in a table and show delivery status in the staff dashboard.
- Notifications must really send when real provider keys are configured, and fall back to the console in demo mode. Document the setup in the README. Note in the README that sending SMS in India requires DLT registration (entity, sender ID and template approval) with the chosen provider, so templates must be registered before real use.

## 9. Data model (minimum)

`Parent`, `OtpRequest`, `School` (seeded from the JSON, including `verification`, `sources`), `ApplicationDraft`, `Application` (id, parentId, schoolId, status, currentStage, answers JSON, createdAt), `Document`, `StageDecision` (stage, staffId, decision, note, at), `StaffUser` (role, schoolId), `Notification`, `AuditLog`. Add indexes on schoolId, status, applicationId, parent mobile.

## 10. Security, privacy and compliance

- Treat children's data as sensitive: encrypt documents at rest where possible, signed URLs for downloads, mask Aadhaar to the last 4 digits on screen, never log full OTPs or Aadhaar in production.
- Consent screen before data collection explaining purpose and who sees it (only the selected school's staff). Follow India's DPDP Act principles: purpose limitation, parental consent for a child's data, easy deletion request.
- Validate and sanitise all inputs; limit upload types/sizes; CSRF protection; rate-limit OTP and login.
- Add a visible disclaimer: "This portal helps you submit an application. Admission is decided by the school."

## 11. Quality bar

- Zero placeholder lorem ipsum; use real copy in English and Tamil.
- Empty, loading and error states for every screen.
- Seed script: `npm run seed` loads `schools_thoothukudi.json` and creates demo staff accounts.
- One-command start: `npm install && npm run seed && npm run dev`.
- Write a `README.md` explaining setup, env variables, how to switch SMS providers, how to add a school (edit the JSON, run seed), and how to mark a school's `verification` status.
- Add tests for OTP, the stage-order rules, application-ID generation, and the school search/filter.
- Before finishing, run the app, walk through BOTH methods end to end in a browser, fix any bugs, and report what you verified.

## 12. What not to do

- Do not scrape or hotlink school logos/photos without permission; use neutral placeholders.
- Do not show fake fees, ratings, seat counts, or staff names.
- Do not claim the school has agreed to use this portal unless a school is marked as onboarded in the data.
- Do not auto-send real SMS in development unless real provider keys are explicitly configured.

Deliver a fully working project with all pages above, seeded real school data, and clear instructions to run it.
